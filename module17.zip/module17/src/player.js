import React, { Component } from "react";
import './player.css';
class Stuff extends Component {
  render() {
    return (
      <div class = "input-control">
        <label1 for = "player1" >P1: <input type = "text" id = "player1" placeholder = "enter the name of player1" autofocus/></label1><br/>
        <label1 for = "player1">Colour <select id="colour" name="colour">
                    <option value="australia">blue</option>
                    <option value="canada">green</option>
                    <option value="usa">yellow</option>
                  </select></label1><br/>
        
        <div class = "input-control-1">
        <label1 for = "player2">P2: <input type = "text" id = "player2" placeholder = "enter the name of player 2" autofocus/></label1><br/>
        <label1 for = "player1">Colour <select id="colour" name="colour">
                    <option value="australia">blue</option>
                    <option value="canada">green</option>
                    <option value="usa">yellow</option>
                  </select></label1><br/>
      <div class="submit">
      <button>Submit</button>
      </div>
      </div>
      </div>
    );
  }
}
export default Stuff;