import React, { Component } from "react";
import {
    Route,
    NavLink,
    HashRouter
  } from "react-router-dom";
  import Home from "./Home";
  import player from "./player";
  import game from "./game";
  import computer from "./Game1";
class Main extends Component {
  render() {
    return (
        <HashRouter>
        <div>
        
          <ul className="header">
          <li><NavLink exact to="/">Home |</NavLink></li>
            <li><NavLink to="/player">Game</NavLink></li>
          </ul>
          <div className="content">
          <Route exact path="/" component={Home}/>
            <Route path="/player" component={player}/>
            <Route path="/game" component={game}/>
            <Route path="/Game1" component={computer}/>
          </div>
        </div>
        </HashRouter>
    );
  }
}
 
export default Main;