import React, { Component } from "react";
import './player.css';
import {
  NavLink
} from "react-router-dom";
class Stuff extends Component {
  render() {
    return (
      <header className="main-header">
  <h1 className="game-title">
    <span className="small">Connect</span>
    <span className="big">Four</span>
    <div class="circles">
  <div class="circle red-sm"></div>
  <div class="circle yellow-sm"></div>
  <div class="circle red-sm"></div>
  <div class="circle yellow-sm"></div>
  <div class="circle red-sm"></div>
  <div class="circle yellow-sm"></div>
  <div class="circle red-sm"></div>
  <div class="circle yellow-sm"></div>
</div>
    </h1>
<br></br><br></br><br></br>
<section className="main-navigation">
<NavLink to="/Game1"><button className="nav-btn" >
    Player vs Computer
    </button></NavLink>
  
  <NavLink to="/game"><button className="nav-btn">
  Player vs Player
    </button></NavLink>
</section>;
</header>
    );
  }
}

export default Stuff;